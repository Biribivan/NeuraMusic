package com.example.neuramusic.utils;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

@GlideModule
public final class MyAppGlideModule extends AppGlideModule {
    // Vacío, pero necesario para generar GlideApp y evitar el warning
}
