package com.example.neuramusic.adapters;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.example.neuramusic.model.ProfileBlock;
import com.example.neuramusic.adapters.viewholders.ImageBlockViewHolder;
import com.example.neuramusic.adapters.viewholders.TextBlockViewHolder;

import java.util.List;

public class BlockAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final List<ProfileBlock> blockList;

    public BlockAdapter(List<ProfileBlock> blockList) {
        this.blockList = blockList;
    }

    @Override
    public int getItemViewType(int position) {
        String type = blockList.get(position).getType();
        return type.equals("image") ? 1 : 0;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == 1) {
            return new ImageBlockViewHolder(LayoutInflater.from(parent.getContext())
                    .inflate(android.R.layout.simple_list_item_1, parent, false));
        } else {
            return new TextBlockViewHolder(LayoutInflater.from(parent.getContext())
                    .inflate(android.R.layout.simple_list_item_1, parent, false));
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ProfileBlock block = blockList.get(position);

        if (holder instanceof TextBlockViewHolder) {
            ((TextBlockViewHolder) holder).bind(block);
        } else if (holder instanceof ImageBlockViewHolder) {
            ((ImageBlockViewHolder) holder).bind(block);
        }
    }

    @Override
    public int getItemCount() {
        return blockList.size();
    }
}
