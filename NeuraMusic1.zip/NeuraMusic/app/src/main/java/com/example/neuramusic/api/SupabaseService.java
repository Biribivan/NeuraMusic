package com.example.neuramusic.api;

import com.example.neuramusic.model.AuthRequest;
import com.example.neuramusic.model.ProfileBlock;
import com.example.neuramusic.model.UserRequest;

import java.util.List;
import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.*;

public interface SupabaseService {

    // Registro de usuario (auth)
    @POST("auth/v1/signup")
    @Headers("Content-Type: application/json")
    Call<ResponseBody> signUp(
            @Body AuthRequest request,
            @Header("apikey") String apiKey
    );

    // Insertar datos adicionales del usuario en la tabla 'users'
    @POST("rest/v1/users")
    @Headers({
            "Content-Type: application/json",
            "Prefer: return=minimal"
    })
    Call<Void> insertUser(
            @Body UserRequest request,
            @Header("apikey") String apiKey,
            @Header("Authorization") String bearerToken
    );

    // Login con email y contraseña (FIXED HEADERS)
    @POST("auth/v1/token?grant_type=password")
    @Headers("Content-Type: application/json")
    Call<ResponseBody> login(
            @Body AuthRequest request,
            @Header("apikey") String apiKey
    );

    // Obtener usuario desde la tabla 'users' por su ID
    @GET("rest/v1/users")
    Call<ResponseBody> getUserById(
            @Query("id") String filter,
            @Header("apikey") String apiKey,
            @Header("Authorization") String authHeader
    );

    // Subir imagen de perfil
    @Multipart
    @POST("storage/v1/object/user-images")
    Call<ResponseBody> uploadProfileImage(
            @Part MultipartBody.Part file,
            @Header("Authorization") String authHeader,
            @Header("apikey") String apiKey,
            @Query("name") String fileName
    );

    // Obtener bloques tipo Pinterest por usuario
    @GET("profile_blocks")
    Call<List<ProfileBlock>> getProfileBlocksByUserId(
            @QueryMap Map<String, String> queries,
            @Header("apikey") String apiKey,
            @Header("Authorization") String authHeader
    );

    // Crear bloque
    @POST("profile_blocks")
    Call<ProfileBlock> createProfileBlock(
            @Body ProfileBlock block,
            @Header("apikey") String apiKey,
            @Header("Authorization") String authHeader
    );

    // Actualizar bloque por ID
    @PATCH("profile_blocks?id=eq.{id}")
    Call<ProfileBlock> updateProfileBlock(
            @Path("id") String id,
            @Body ProfileBlock updatedBlock,
            @Header("apikey") String apiKey,
            @Header("Authorization") String authHeader
    );

    // Eliminar bloque por ID
    @DELETE("profile_blocks?id=eq.{id}")
    Call<Void> deleteProfileBlock(
            @Path("id") String id,
            @Header("apikey") String apiKey,
            @Header("Authorization") String authHeader
    );
}
