package com.example.neuramusic.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.bumptech.glide.Glide;
import com.example.neuramusic.R;
import com.example.neuramusic.adapters.BlockAdapter;
import com.example.neuramusic.api.RetrofitClient;
import com.example.neuramusic.api.SupabaseService;
import com.example.neuramusic.model.ProfileBlock;
import com.example.neuramusic.model.UserResponse;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserProfileActivity extends AppCompatActivity {

    private TextView tvUsername, tvName, tvProfession, tvBio;
    private ImageView ivProfile;
    private ImageButton btnBack, btnSettings, btnInstagram, btnYoutube, btnSpotify, btnSoundcloud;

    private SupabaseService supabaseService;
    private SharedPreferences prefs;
    private RecyclerView rvBlocks;
    private BlockAdapter blockAdapter;
    private List<ProfileBlock> blockList = new ArrayList<>();

    private static final String TAG = "UserProfileActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        // 🎯 Setup RecyclerView estilo Pinterest
        rvBlocks = findViewById(R.id.rvBlocks);
        StaggeredGridLayoutManager layoutManager = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
        rvBlocks.setLayoutManager(layoutManager);
        blockAdapter = new BlockAdapter(blockList);
        rvBlocks.setAdapter(blockAdapter);

        prefs = getSharedPreferences("NeuraPrefs", MODE_PRIVATE);
        String userId = prefs.getString("user_id", null);
        String accessToken = prefs.getString("access_token", null);

        if (userId == null || accessToken == null) {
            Toast.makeText(this, "Sesión expirada", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        initViews();
        setupButtons();

        supabaseService = RetrofitClient.getClient().create(SupabaseService.class);
        loadUserData(userId, accessToken);
    }

    private void initViews() {
        tvUsername = findViewById(R.id.tvUsername);
        tvName = findViewById(R.id.tvName);
        tvProfession = findViewById(R.id.tvProfession);
        tvBio = findViewById(R.id.tvBio);
        ivProfile = findViewById(R.id.ivProfile);

        btnBack = findViewById(R.id.btnBack);
        btnSettings = findViewById(R.id.btnSettings);
        btnInstagram = findViewById(R.id.btnInstagram);
        btnYoutube = findViewById(R.id.btnYoutube);
        btnSpotify = findViewById(R.id.btnSpotify);
        btnSoundcloud = findViewById(R.id.btnSoundcloud);
    }

    private void setupButtons() {
        btnBack.setOnClickListener(v -> onBackPressed());
        btnSettings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
    }

    private void loadUserData(String userId, String accessToken) {
        String filter = "eq." + userId;

        supabaseService.getUserById(filter, RetrofitClient.API_KEY, "Bearer " + accessToken)
                .enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            try {
                                String json = response.body().string();
                                Type listType = new TypeToken<List<UserResponse>>() {}.getType();
                                List<UserResponse> users = new Gson().fromJson(json, listType);

                                if (!users.isEmpty()) {
                                    UserResponse user = users.get(0);
                                    populateUserInfo(user);
                                    loadBlocks(user.uid); // 👈 ¡Ahora sí!
                                }

                            } catch (Exception e) {
                                Log.e(TAG, "Error al leer usuario", e);
                            }
                        } else {
                            Log.e(TAG, "No se pudo cargar el perfil del usuario");
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        Log.e(TAG, "Fallo de red al obtener usuario", t);
                    }
                });
    }

    private void loadBlocks(String userId) {
        Map<String, String> query = new HashMap<>();
        query.put("user_id", "eq." + userId);
        query.put("order", "position.asc");

        String token = prefs.getString("access_token", null);

        supabaseService.getProfileBlocksByUserId(query, RetrofitClient.API_KEY, "Bearer " + token)
                .enqueue(new Callback<List<ProfileBlock>>() {
                    @Override
                    public void onResponse(Call<List<ProfileBlock>> call, Response<List<ProfileBlock>> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            blockList.clear();
                            blockList.addAll(response.body());
                            blockAdapter.notifyDataSetChanged();
                        } else {
                            Log.e(TAG, "Error al cargar bloques: " + response.message());
                        }
                    }

                    @Override
                    public void onFailure(Call<List<ProfileBlock>> call, Throwable t) {
                        Log.e(TAG, "Fallo de red al obtener bloques", t);
                    }
                });
    }

    private void populateUserInfo(UserResponse user) {
        tvUsername.setText("@" + user.username);
        tvName.setText(user.username); // Puedes usar nombre completo si lo tienes
        tvProfession.setText(user.role != null ? user.role : "Artista");
        tvBio.setText(user.bio != null ? user.bio : "");

        if (user.profileImageUrl != null && !user.profileImageUrl.isEmpty()) {
            Glide.with(this)
                    .load(user.profileImageUrl)
                    .placeholder(R.drawable.ic_user)
                    .into(ivProfile);
        }

        setupSocialLink(btnInstagram, user.instagram);
        setupSocialLink(btnYoutube, user.youtube);
        setupSocialLink(btnSpotify, user.spotify);
        setupSocialLink(btnSoundcloud, user.soundcloud);
    }

    private void setupSocialLink(ImageButton button, String url) {
        if (url != null && !url.trim().isEmpty()) {
            button.setVisibility(View.VISIBLE);
            button.setOnClickListener(v -> {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(browserIntent);
            });
        } else {
            button.setVisibility(View.GONE);
        }
    }
}
