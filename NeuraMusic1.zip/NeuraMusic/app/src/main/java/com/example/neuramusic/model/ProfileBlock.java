package com.example.neuramusic.model;

import com.google.gson.annotations.SerializedName;

import java.util.Map;
import java.util.UUID;

public class ProfileBlock {

    @SerializedName("id")
    private UUID id;

    @SerializedName("user_id")
    private UUID userId;

    @SerializedName("type")
    private String type;

    @SerializedName("data")
    private Map<String, Object> data;

    @SerializedName("position")
    private int position;

    @SerializedName("created_at")
    private String createdAt;

    // Getters y setters
    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public UUID getUserId() {
        return userId;
    }

    public void setUserId(UUID userId) {
        this.userId = userId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
}
