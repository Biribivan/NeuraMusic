package com.example.neuramusic.activities;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.neuramusic.R;
import com.example.neuramusic.adapters.BlockAdapter;
import com.example.neuramusic.api.RetrofitClient;
import com.example.neuramusic.api.SupabaseService;
import com.example.neuramusic.model.ProfileBlock;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditorActivity extends AppCompatActivity {

    private RecyclerView rvBlocks;
    private FloatingActionButton fabAddBlock;
    private SupabaseService supabaseService;

    private static final String API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imx4b3hoZG1paHlkam90c2dncGNvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDgzNzk3MjYsImV4cCI6MjA2Mzk1NTcyNn0.Cg4fm9x0NqlkSxtMTvMMFZJ-MNDoN1-u4ymKr7NdzR0";
    private String authToken;
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);

        rvBlocks = findViewById(R.id.rvBlocks);
        fabAddBlock = findViewById(R.id.fabAddBlock);
        rvBlocks.setLayoutManager(new LinearLayoutManager(this));

        supabaseService = RetrofitClient.getClient().create(SupabaseService.class);

        SharedPreferences prefs = getSharedPreferences("NeuraPrefs", MODE_PRIVATE);
        userId = prefs.getString("user_id", null);
        String token = prefs.getString("access_token", null);

        if (userId == null || token == null) {
            Toast.makeText(this, "No se pudo autenticar usuario", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        authToken = "Bearer " + token;

        loadBlocks();

        fabAddBlock.setOnClickListener(view -> showAddTextBlockDialog());
    }

    private void loadBlocks() {
        Map<String, String> queries = new HashMap<>();
        queries.put("user_id", "eq." + userId);
        queries.put("order", "position.asc");

        supabaseService.getProfileBlocksByUserId(queries, API_KEY, authToken)
                .enqueue(new Callback<List<ProfileBlock>>() {
                    @Override
                    public void onResponse(Call<List<ProfileBlock>> call, Response<List<ProfileBlock>> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            BlockAdapter adapter = new BlockAdapter(response.body());
                            rvBlocks.setAdapter(adapter);
                        } else {
                            Log.e("EDITOR", "Error al cargar bloques: " + response.message());
                        }
                    }

                    @Override
                    public void onFailure(Call<List<ProfileBlock>> call, Throwable t) {
                        Log.e("EDITOR", "Fallo de red", t);
                    }
                });
    }

    private void showAddTextBlockDialog() {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_text_block, null);

        EditText etTitle = dialogView.findViewById(R.id.etTitle);
        EditText etContent = dialogView.findViewById(R.id.etContent);


        new AlertDialog.Builder(this)
                .setTitle("Nuevo bloque de texto")
                .setView(dialogView)
                .setPositiveButton("Guardar", (dialog, which) -> {
                    String title = etTitle.getText().toString().trim();
                    String content = etContent.getText().toString().trim();


                    if (content.isEmpty()) {
                        Toast.makeText(this, "El contenido no puede estar vacío", Toast.LENGTH_SHORT).show();
                        return;
                    }


                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void createTextBlock(String title, String content, boolean isBold, boolean isItalic) {
        Map<String, Object> data = new HashMap<>();
        data.put("title", title);
        data.put("text", content);
        data.put("bold", isBold);
        data.put("italic", isItalic);

        ProfileBlock block = new ProfileBlock();
        block.setUserId(UUID.fromString(userId));
        block.setType("text");
        block.setData(data);
        block.setPosition(0); // TODO: puedes hacer lógica de orden

        supabaseService.createProfileBlock(block, API_KEY, authToken)
                .enqueue(new Callback<ProfileBlock>() {
                    @Override
                    public void onResponse(Call<ProfileBlock> call, Response<ProfileBlock> response) {
                        if (response.isSuccessful()) {
                            Toast.makeText(EditorActivity.this, "Bloque guardado", Toast.LENGTH_SHORT).show();
                            loadBlocks();
                        } else {
                            Log.e("EDITOR", "Error al guardar bloque: " + response.message());
                        }
                    }

                    @Override
                    public void onFailure(Call<ProfileBlock> call, Throwable t) {
                        Log.e("EDITOR", "Fallo al guardar bloque", t);
                    }
                });
    }
}
