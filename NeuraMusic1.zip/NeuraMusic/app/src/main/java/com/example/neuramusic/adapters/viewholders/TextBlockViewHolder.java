package com.example.neuramusic.adapters.viewholders;

import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.neuramusic.model.ProfileBlock;

public class TextBlockViewHolder extends RecyclerView.ViewHolder {

    private final TextView textView;

    public TextBlockViewHolder(View itemView) {
        super(itemView);
        textView = (TextView) itemView.findViewById(android.R.id.text1);
    }

    public void bind(ProfileBlock block) {
        Object text = block.getData().get("text");
        textView.setText(text != null ? text.toString() : "(Sin texto)");
    }
}
