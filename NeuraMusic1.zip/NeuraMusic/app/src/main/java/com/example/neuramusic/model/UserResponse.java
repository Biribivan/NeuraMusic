package com.example.neuramusic.model;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

public class UserResponse {

    @SerializedName("id")
    public String uid;

    @SerializedName("email")
    public String email;

    @SerializedName("role")
    public String role;

    @SerializedName("username")
    public String username;

    @SerializedName("name")
    public String name;

    @SerializedName("profession")
    public String profession;

    @SerializedName("bio")
    public String bio;

    @SerializedName("dob")
    public String dob;

    @SerializedName("instagram")
    public String instagram;

    @SerializedName("soundcloud")
    public String soundcloud;

    @SerializedName("spotify")
    public String spotify;

    @SerializedName("youtube")
    public String youtube;

    @SerializedName("is_blocked")
    public boolean isBlocked;

    @SerializedName("is_approved")
    public boolean isApproved;

    @SerializedName("created_at")
    public String createdAt;

    @SerializedName("profile_image_url")
    public String profileImageUrl;

    // Constructor vacío requerido por Gson
    public UserResponse() {}

    // Método utilitario para parsear JSON
    public static UserResponse fromJson(String json) {
        try {
            // Supabase devuelve un array de usuarios
            UserResponse[] arr = new Gson().fromJson(json, UserResponse[].class);
            return arr.length > 0 ? arr[0] : null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Opcional: para logs/debug
    @Override
    public String toString() {
        return "UserResponse{" +
                "uid='" + uid + '\'' +
                ", username='" + username + '\'' +
                ", email='" + email + '\'' +
                ", name='" + name + '\'' +
                ", profession='" + profession + '\'' +
                ", role='" + role + '\'' +
                '}';
    }
}
